import os
def suchDogeMuchAscii():
    os.system('cls' if os.name == 'nt' else 'clear');
    soString = """\033[93m
                Y.                      _
                YiL                   .```.
                Yii;       WOW      .; .;;`.
                YY;ii._           .;`.;;;; :
                iiYYYYYYiiiii;;;;i` ;;::;;;;
            _.;YYYYYYiiiiiiYYYii  .;;.   ;;;
         .YYYYYYYYYYiiYYYYYYYYYYYYii;`  ;;;;
       .YYYYYYY$$YYiiYY$$$$iiiYYYYYY;.ii;`..
      :YYY$!.  TYiiYY$$$$$YYYYYYYiiYYYYiYYii.
      Y$MM$:   :YYYYYY$!"``"4YYYYYiiiYYYYiiYY.
   `. :MM$$b.,dYY$$Yii" :'   :YYYYllYiiYYYiYY
_.._ :`4MM$!YYYYYYYYYii,.__.diii$$YYYYYYYYYYY
.,._ $b`P`     "4$$$$$iiiiiiii$$$$YY$$$$$$YiY;
   `,.`$:       :$$$$$$$$$YYYYY$$$$$$$$$YYiiYYL
    "`;$$.    .;PPb$`.,.``T$$YY$$$$YYYYYYiiiYYU:
    ;$P$;;: ;;;;i$y$"!Y$$$b;$$$Y$YY$$YYYiiiYYiYY
    $Fi$$ .. ``:iii.`-":YYYYY$$YY$$$$$YYYiiYiYYY
    :Y$$rb ````  `_..;;i;YYY$YY$$$$$$$YYYYYYYiYY:
     :$$$$$i;;iiiiidYYYYYYYYYY$$$$$$YYYYYYYiiYYYY.
      `$$$$$$$YYYYYYYYYYYYY$$$$$$YYYYYYYYiiiYYYYYY
      .i!$$$$$$YYYYYYYYY$$$$$$YYY$$YYiiiiiiYYYYYYY
     :YYiii$$$$$$$YYYYYYY$$$$YY$$$$YYiiiiiYYYYYYi'
    \033[0m"""
    print(soString)

def iicsAhcuMegoDhcus():
    os.system('cls' if os.name == 'nt' else 'clear');
    gnirtSos = """\033[93m
          _                      .Y
        .```.                   LiY
       .`;;. ;.      WOW       ;iiY
       : ;;;;.`;.           _.ii;YY
       ;;;;::;; `i;;;;iiiiiYYYYYYii
       ;;;   .;;.  iiYYYiiiiiiYYYYYY;._
       ;;;;  `;iiYYYYYYYYYYYYiiYYYYYYYYYY.
       ..`;ii.;YYYYYYiii$$$$YYiiYY$$YYYYYYY.
      .iiYYiYYYYiiYYYYYYY$$$$$YYiiYT  .!$YYY:
     .YYiiYYYYiiiYYYYY4"``"!$YYYYYY:   :$MM$Y
      YYiYYYiiYllYYYY:   ': "iiY$$YYb,.d$$MM: .`
      YYYYYYYYYYY$$iiib.__.,iiYYYYYYYYY!$MM4`: _.._
     ;YiY$$$$$$YY$$$$iiiiiiii$$$$$4"     `P`d$ _.,.
    LYYiiYY$$$$$$$$$YYYYY$$$$$$$$$:       :$`.,`
   :UYYiiiYYYYYY$$$$YY$$T``.,.`$dPP;.    .$$;`"
   YYiYYiiiYYY$$YY$Y$$$;d$$$Y!"$y$i;;;; :;;$P$;
   YYYiYiiYYY$$$$$YY$$YYYYY:"-`.iii:`` .. $$iF$
  :YYiYYYYYYY$$$$$$$YY$YYY;i;;.._`  ```` dr$$Y:
 .YYYYiiYYYYYYY$$$$$$YYYYYYYYYYbiiiii;;i$$$$$:
 YYYYYYiiiYYYYYYYY$$$$$$YYYYYYYYYYYYY$$$$$$$`
 YYYYYYYiiiiiiYY$$YYY$$$$$$YYYYYYYYY$$$$$$!i.
 'iYYYYYYiiiiiYY$$$$YY$$$$YYYYYYY$$$$$$$iiiYY:
    \033[0m"""
    print(gnirtSos)