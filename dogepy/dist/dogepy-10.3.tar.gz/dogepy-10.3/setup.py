from setuptools import setup


setup(name='dogepy',
      version='10.3',
      description='So doge, much art, wow',
      url='https://github.com/laasli/doge',
      author='Laasli, Morz',
      author_email='morzzz007@gmail.com',
      license='BSD',
      packages=['dogepy'],
      zip_safe=True)
